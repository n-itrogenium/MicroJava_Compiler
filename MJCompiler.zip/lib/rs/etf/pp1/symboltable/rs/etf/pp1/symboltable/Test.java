package rs.etf.pp1.symboltable;


public class Test {

	public static void main(String[] args) {
		Tab.init();
		Tab.dump();
	}
}
